export default function AddProduct() {
  return (
    <div className="flex flex-col h-full bg-white rounded shadow-sm border border-gray-200 p-4">
      <div className="text-gray-800 text-[14px] font-medium mb-4">添加商品</div>
      <div className="text-[13px] text-gray-600">
        页面建设中…
      </div>
    </div>
  );
}


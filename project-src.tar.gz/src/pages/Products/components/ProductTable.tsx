import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Checkbox } from '@/components/ui/checkbox';
import { Input } from '@/components/ui/input';
import { ChevronDown, Edit, Copy, MessageSquare, MoreHorizontal, Image as ImageIcon, Search, Settings, RefreshCw, Printer, Plus } from 'lucide-react';
import { FeatureMarker } from '@/components/FeatureMarker';

interface ProductTableProps {
  filterValues: any;
}

export default function ProductTable({ filterValues }: ProductTableProps) {
  const [selectedIds, setSelectedIds] = useState<string[]>([]);

  const mockData = [
    {
      id: '1',
      thumb: 'https://via.placeholder.com/40',
      sku: '10006231-0-A0-TSG',
      name: 'TSG生产耗材烫钻-D款_银色',
      status: '正常销售',
      inventory: { total: 0, inTransit: 200, unshipped: '0(0/0/0/0)', preInbound: 0, available: 0 },
      sales: { history: '0/0/0', forecast: '0.000' },
      weight: '10.00',
      supplier: '何江涛',
      lastOutbound: '--',
      price: '--',
      cost: '--',
      developer: '--',
      brand: '--',
      multiAttr: '--',
      dimensions: '--',
      packedWeight: '--',
      packedDimensions: '--',
      createTime: '--',
      creator: '--',
      category: '--',
      purchaser: '--'
    },
    {
      id: '2',
      thumb: 'https://via.placeholder.com/40',
      sku: '10006230-G0-A0-GC',
      name: '单件定制-XHP钛钢浮雕耳钉_金色_EDTGGC-3',
      status: '正常销售',
      inventory: { total: 0, inTransit: 0, unshipped: '0(0/0/0/0)', preInbound: 0, available: 0 },
      sales: { history: '0/0/0', forecast: '0.000' },
      weight: '12.00',
      supplier: '深圳市宸光珠宝...',
      lastOutbound: '--',
      price: '--',
      cost: '--',
      developer: '--',
      brand: '--',
      multiAttr: '--',
      dimensions: '--',
      packedWeight: '--',
      packedDimensions: '--',
      createTime: '--',
      creator: '--',
      category: '--',
      purchaser: '--'
    },
    {
      id: '3',
      thumb: 'https://via.placeholder.com/40',
      sku: '10005605-GG-B0-ET-PJ',
      name: 'ET_PJ撞色手提枕头化妆包_绿白小号',
      status: '正常销售',
      inventory: { total: 0, inTransit: 0, unshipped: '0(0/0/0/0)', preInbound: 0, available: 0 },
      sales: { history: '0/0/0', forecast: '0.000' },
      weight: '100.00',
      supplier: '义乌飞泓箱包有...',
      lastOutbound: '--',
      price: '--',
      cost: '--',
      developer: '--',
      brand: '--',
      multiAttr: '--',
      dimensions: '--',
      packedWeight: '--',
      packedDimensions: '--',
      createTime: '--',
      creator: '--',
      category: '--',
      purchaser: '--'
    }
  ];

  const handleSelectAll = (checked: boolean) => {
    if (checked) setSelectedIds(mockData.map(d => d.id));
    else setSelectedIds([]);
  };

  return (
    <div className="flex flex-col h-full relative">
      {/* Action Bar */}
      <div className="p-2 border-b border-gray-200 flex flex-wrap items-center gap-2 bg-[#F8FAFC] shrink-0 text-[13px]">
        <FeatureMarker title="批处理功能" description="对选中的商品执行批量操作（如下架、修改分类、更新状态等）。">
          <Button className="h-7 bg-[#6B8EBE] hover:bg-[#5A7BA8] text-white px-3 gap-1 rounded-sm text-[13px]">
            <Edit className="w-3.5 h-3.5" /> 批处理功能 <ChevronDown className="w-3.5 h-3.5" />
          </Button>
        </FeatureMarker>

        <FeatureMarker title="更多功能" description="包含更多不常用的扩展操作菜单。">
          <Button className="h-7 bg-[#6B8EBE] hover:bg-[#5A7BA8] text-white px-3 gap-1 rounded-sm text-[13px]">
            <Settings className="w-3.5 h-3.5" /> 更多功能 <ChevronDown className="w-3.5 h-3.5" />
          </Button>
        </FeatureMarker>

        <FeatureMarker title="打印中心" description="批量打印选中商品的条码或标签。">
          <Button className="h-7 bg-[#F0B144] hover:bg-[#E0A134] text-white px-3 gap-1 rounded-sm text-[13px]">
            <Printer className="w-3.5 h-3.5" /> 打印中心 <ChevronDown className="w-3.5 h-3.5" />
          </Button>
        </FeatureMarker>

        <FeatureMarker title="图片管理" description="管理商品的图库、主图及辅图信息。">
          <Button className="h-7 bg-[#8CC63F] hover:bg-[#7AB62F] text-white px-3 gap-1 rounded-sm text-[13px]">
            <ImageIcon className="w-3.5 h-3.5" /> 图片管理
          </Button>
        </FeatureMarker>

        <Button className="h-7 bg-[#8CB5E2] hover:bg-[#7AA4D1] text-white px-3 gap-1 rounded-sm text-[13px]">
          排序 <ChevronDown className="w-3.5 h-3.5" />
        </Button>
        <Button className="h-7 bg-[#8CB5E2] hover:bg-[#7AA4D1] text-white px-3 gap-1 rounded-sm text-[13px]">
          数据刷新 <ChevronDown className="w-3.5 h-3.5" />
        </Button>

        <label className="flex items-center gap-1.5 ml-2 cursor-pointer">
          <input type="checkbox" defaultChecked className="w-3.5 h-3.5 text-blue-600 rounded-sm" />
          <span className="text-red-500 font-medium">显示平台仓库库存</span>
        </label>

        <div className="ml-auto flex items-center gap-3">
          <span className="text-blue-600 cursor-pointer hover:underline">SKU库存查询</span>
          <Button className="h-7 bg-[#6B8EBE] hover:bg-[#5A7BA8] text-white px-3 rounded-sm text-[13px]">
            导入商品目录
          </Button>
          <FeatureMarker title="添加/导出" description="支持手动添加单个商品，或将列表内商品数据导出为 Excel 文件。">
            <Button className="h-7 bg-[#6B8EBE] hover:bg-[#5A7BA8] text-white px-3 gap-1 rounded-sm text-[13px]">
              <Plus className="w-3.5 h-3.5" /> 添加/导出 <ChevronDown className="w-3.5 h-3.5" />
            </Button>
          </FeatureMarker>
        </div>
      </div>

      {/* Table Container */}
      <div className="flex-1 overflow-auto custom-scrollbar relative">
        <table className="w-full text-center text-[12px] border-collapse min-w-[1800px]">
          <thead className="bg-[#F8FAFC] text-gray-600 sticky top-0 z-10 shadow-sm">
            <tr>
              <th className="p-2 font-normal border-b border-r border-gray-200 w-10">
                <Checkbox 
                  checked={selectedIds.length === mockData.length && mockData.length > 0}
                  onCheckedChange={handleSelectAll}
                />
              </th>
              <th className="p-2 font-normal border-b border-r border-gray-200 w-24">
                <div className="flex items-center justify-center gap-1">
                  <span className="text-blue-500 border border-blue-500 rounded-full w-4 h-4 flex items-center justify-center cursor-pointer">+</span>
                  缩略图
                </div>
              </th>
              <th className="p-2 font-normal border-b border-r border-gray-200 w-64 text-blue-600 cursor-pointer hover:underline">
                库存SKU ↕<br/>商品中文名 ↕
              </th>
              <th className="p-2 font-normal border-b border-r border-gray-200 w-24">状态</th>
              <th className="p-2 font-normal border-b border-r border-gray-200 w-40 text-blue-600 cursor-pointer hover:underline">
                库存总量(个) ↕<br/>在途量 ↕<br/>
                <span className="text-gray-600 no-underline cursor-default flex items-center justify-center gap-1">
                  <span className="bg-blue-600 text-white rounded-full w-3.5 h-3.5 flex items-center justify-center text-[10px]">?</span>
                  未发货数量 ↕
                </span>
                预调入量<br/>
                <span className="text-gray-600 no-underline cursor-default flex items-center justify-center gap-1">
                  <span className="bg-blue-600 text-white rounded-full w-3.5 h-3.5 flex items-center justify-center text-[10px]">?</span>
                  可用库存
                </span>
              </th>
              <th className="p-2 font-normal border-b border-r border-gray-200 w-32 text-blue-600 cursor-pointer hover:underline">
                销量(7/28/42) ↕<br/>预测日销量(个) ↕
              </th>
              <th className="p-2 font-normal border-b border-r border-gray-200 w-24 text-blue-600 cursor-pointer hover:underline">重量(g) ↕</th>
              <th className="p-2 font-normal border-b border-r border-gray-200 w-32">默认供应商</th>
              <th className="p-2 font-normal border-b border-gray-200 w-24">操作</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-gray-100">
            {mockData.map((item, idx) => (
              <tr key={item.id} className="hover:bg-blue-50/30">
                <td className="p-2 border-r border-gray-100">
                  <div className="flex items-center justify-center gap-2">
                    <Checkbox 
                      checked={selectedIds.includes(item.id)}
                      onCheckedChange={(c) => setSelectedIds(c ? [...selectedIds, item.id] : selectedIds.filter(id => id !== item.id))}
                    />
                    <span>{idx + 1}</span>
                  </div>
                </td>
                <td className="p-2 border-r border-gray-100">
                  <div className="flex flex-col items-center gap-1">
                    <img src={item.thumb} alt="thumb" className="w-10 h-10 border border-gray-200 rounded object-cover" />
                    <span className="text-blue-500 cursor-pointer hover:underline text-[10px]">添加1688链<br/>接查找货源</span>
                  </div>
                </td>
                <td className="p-2 border-r border-gray-100 text-left px-4">
                  <div className="flex items-center gap-1 text-blue-600 cursor-pointer hover:underline font-medium">
                    <span className="border border-blue-500 rounded-full w-3.5 h-3.5 flex items-center justify-center text-[10px]">+</span>
                    {item.sku}
                  </div>
                  <div className="text-gray-700 mt-1">{item.name}</div>
                  <div className="flex items-center gap-2 mt-2">
                    {idx > 1 && <span className="text-blue-500 hover:underline cursor-pointer">1688</span>}
                    {idx > 1 && <span className="bg-[#8CC63F] text-white px-1.5 py-0.5 rounded-sm text-[10px] flex items-center gap-1 cursor-pointer"><ImageIcon className="w-3 h-3"/> 同款降本</span>}
                    <span className="border border-orange-500 text-orange-500 px-1.5 py-0.5 rounded-sm text-[10px] flex items-center gap-1 cursor-pointer">
                      <Search className="w-3 h-3"/> 找同款
                    </span>
                  </div>
                </td>
                <td className="p-2 border-r border-gray-100 text-green-500">{item.status}</td>
                <td className="p-2 border-r border-gray-100">
                  <div className="text-gray-800">{item.inventory.total}</div>
                  <div className="text-gray-800 flex items-center justify-center gap-1">{item.inventory.inTransit} <span className="text-blue-500 cursor-pointer">≡</span></div>
                  <div className="text-gray-800">{item.inventory.unshipped}</div>
                  <div className="text-gray-800 flex items-center justify-center gap-1">{item.inventory.preInbound} <span className="text-blue-500 cursor-pointer">≡</span></div>
                  <div className="text-gray-800">{item.inventory.available}</div>
                </td>
                <td className="p-2 border-r border-gray-100">
                  <div className="text-gray-800">{item.sales.history}</div>
                  <div className="text-gray-800 flex items-center justify-center gap-1">
                    {item.sales.forecast} <span className="text-blue-500 cursor-pointer border border-blue-500 rounded px-1 text-[10px]">📈</span>
                  </div>
                </td>
                <td className="p-2 border-r border-gray-100 text-gray-800">
                  {item.weight}
                  <div className="mt-4"><span className="text-blue-600 cursor-pointer hover:underline">出入库日志</span></div>
                </td>
                <td className="p-2 border-r border-gray-100 text-gray-800">{item.supplier}</td>
                <td className="p-2 text-blue-600">
                  <div className="flex flex-col items-center gap-1">
                    <span className="cursor-pointer hover:underline">编辑</span>
                    <span className="cursor-pointer hover:underline">复制</span>
                    <span className="cursor-pointer hover:underline">备注</span>
                    <span className="cursor-pointer hover:underline flex items-center">更多 <ChevronDown className="w-3 h-3" /></span>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* Footer Pagination */}
      <div className="p-2 border-t border-gray-200 flex items-center justify-between bg-white text-[12px] text-gray-600 shrink-0">
        <div className="flex items-center gap-2">
          <Button className="h-7 bg-[#34D399] hover:bg-[#2BB280] text-white px-3 rounded-sm text-[12px]">全选</Button>
          <Button variant="outline" className="h-7 border-gray-300 text-gray-600 px-3 rounded-sm text-[12px]">反选</Button>
          <span className="ml-2">每页 100 条 ▲</span>
          <span>共88450条 当前显示第1-100条 1/885页</span>
          
          <div className="flex items-center ml-2 border border-gray-300 rounded overflow-hidden">
            <div className="px-2 py-1 bg-gray-50 border-r border-gray-300 cursor-not-allowed text-gray-400">K</div>
            <div className="px-2 py-1 bg-gray-50 border-r border-gray-300 cursor-not-allowed text-gray-400">{'<'}</div>
            <div className="px-2 py-1 text-red-500 bg-white border-r border-gray-300">1</div>
            <div className="px-2 py-1 bg-white hover:bg-gray-50 cursor-pointer border-r border-gray-300">2</div>
            <div className="px-2 py-1 bg-white hover:bg-gray-50 cursor-pointer border-r border-gray-300">3</div>
            <div className="px-2 py-1 bg-white hover:bg-gray-50 cursor-pointer border-r border-gray-300">4</div>
            <div className="px-2 py-1 bg-white hover:bg-gray-50 cursor-pointer border-r border-gray-300">5</div>
            <div className="px-2 py-1 bg-white hover:bg-gray-50 cursor-pointer border-r border-gray-300">{'>'}</div>
            <div className="px-2 py-1 bg-white hover:bg-gray-50 cursor-pointer">{'▶|'}</div>
          </div>
          
          <Input className="h-7 w-12 text-center text-[12px] focus-visible:ring-0 mx-1" placeholder="页码" />
          <Button variant="outline" className="h-7 text-[12px] border-gray-300">跳转</Button>
        </div>

        <div className="flex items-center gap-1 cursor-pointer text-blue-600 hover:underline">
          <Settings className="w-3.5 h-3.5" /> 自定义列表字段
        </div>
      </div>
    </div>
  );
}

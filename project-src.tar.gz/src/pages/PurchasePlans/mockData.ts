export type PlanItem = {
  id: string;
  buyer: string;
  sku: string;
  name: string;
  warehouse: string;
  quantity: number;
  inbound: string;
  loss: number;
  notes: string;
  logistics: string;
  status: string;
  source: string;
  creator: string;
  createTime: string;
};

export type PlanGroup = {
  planNumber: string;
  supplierName: string;
  totalProducts: number;
  totalQuantity: number;
  totalPrice: number;
  items: PlanItem[];
};

export const mockPlans: PlanGroup[] = [
  {
    planNumber: 'JH20260408092304000',
    supplierName: '深圳优声电子有限公司',
    totalProducts: 1,
    totalQuantity: -51,
    totalPrice: -5100.00,
    items: [
      {
        id: 'p1',
        buyer: '张伟',
        sku: 'CN-BT-001',
        name: '无线蓝牙耳机 Pro Max',
        warehouse: 'wh001',
        quantity: -51,
        inbound: '--',
        loss: 0,
        notes: '...',
        logistics: '--',
        status: '未采购',
        source: '备货建议',
        creator: '系统',
        createTime: '2026/4/8 09:23:04'
      }
    ]
  }
];

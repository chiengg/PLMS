import PlansFilter from './components/PlansFilter';
import PlansTable from './components/PlansTable';

export default function PurchasePlans() {
  return (
    <div className="flex flex-col h-full">
      <div className="flex items-center text-gray-500 text-[13px] mb-4">
        <span>首页</span>
        <span className="mx-2">{'>'}</span>
        <span>采购流程</span>
        <span className="mx-2">{'>'}</span>
        <span className="text-gray-800 font-medium">采购计划</span>
      </div>
      
      <PlansFilter />
      <PlansTable />
    </div>
  );
}

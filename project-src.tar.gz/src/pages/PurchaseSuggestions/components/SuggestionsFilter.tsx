import { useState } from 'react';
import { FeatureMarker } from '@/components/FeatureMarker';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Button } from '@/components/ui/button';
import { Search, Filter, Check, ChevronsUpDown } from 'lucide-react';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { Command, CommandEmpty, CommandGroup, CommandInput, CommandItem, CommandList } from '@/components/ui/command';
import { cn } from '@/lib/utils';

const warehouses = [
  { value: 'FBA-US-东部', label: 'FBA-US-东部' },
  { value: 'FBA-US-西部', label: 'FBA-US-西部' },
  { value: 'FBA-DE-法兰克福', label: 'FBA-DE-法兰克福' },
  { value: 'FBA-UK-伦敦', label: 'FBA-UK-伦敦' },
  { value: 'FBA-JP-东京仓', label: 'FBA-JP-东京仓' },
];

const suppliers = [
  { value: '深圳优声电子有限公司', label: '深圳优声电子有限公司' },
  { value: '广州能量科技有限公司', label: '广州能量科技有限公司' },
  { value: '东莞线材工厂', label: '东莞线材工厂' },
  { value: '惠州硅胶制品有限公司', label: '惠州硅胶制品有限公司' },
];

export default function SuggestionsFilter() {
  const [openSupplier, setOpenSupplier] = useState(false);
  const [supplier, setSupplier] = useState('');

  const [openWarehouse, setOpenWarehouse] = useState(false);
  const [selectedWarehouses, setSelectedWarehouses] = useState<string[]>([]);

  return (
    <div className="flex flex-wrap items-center gap-2 mb-4 bg-white p-3 rounded shadow-sm border border-gray-200">
      <div className="relative w-64">
        <Search className="absolute left-2.5 top-2 h-4 w-4 text-gray-400" />
        <Input 
          placeholder="库存SKU/商品名称/采购员" 
          className="pl-8 h-8 text-[13px] border-gray-300 focus-visible:ring-blue-500"
        />
      </div>
      
      <Select defaultValue="all">
        <SelectTrigger className="w-32 h-8 text-[13px] border-gray-300">
          <SelectValue placeholder="商品状态" />
        </SelectTrigger>
        <SelectContent>
          <SelectItem value="all">全部</SelectItem>
          <SelectItem value="自动创建">自动创建</SelectItem>
          <SelectItem value="等待开发">等待开发</SelectItem>
          <SelectItem value="正常销售">正常销售</SelectItem>
          <SelectItem value="商品清仓">商品清仓</SelectItem>
          <SelectItem value="停止销售">停止销售</SelectItem>
        </SelectContent>
      </Select>
      
      <Select defaultValue="all">
        <SelectTrigger className="w-32 h-8 text-[13px] border-gray-300">
          <SelectValue placeholder="商品活跃度" />
        </SelectTrigger>
        <SelectContent>
          <SelectItem value="all">全部</SelectItem>
          <SelectItem value="爆款">爆款</SelectItem>
          <SelectItem value="旺款">旺款</SelectItem>
          <SelectItem value="平款">平款</SelectItem>
          <SelectItem value="滞销款">滞销款</SelectItem>
        </SelectContent>
      </Select>

      {/* 模糊查询+下拉多选 仓库 */}
      <Popover open={openWarehouse} onOpenChange={setOpenWarehouse}>
        <PopoverTrigger className="inline-flex items-center whitespace-nowrap rounded-md font-medium transition-colors focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring disabled:pointer-events-none disabled:opacity-50 border border-input bg-background hover:bg-accent hover:text-accent-foreground w-48 h-8 px-3 text-[13px] border-gray-300 justify-between">
          {selectedWarehouses.length > 0
            ? `已选 ${selectedWarehouses.length} 个仓库`
            : "选择仓库..."}
          <ChevronsUpDown className="ml-2 h-4 w-4 shrink-0 opacity-50" />
        </PopoverTrigger>
        <PopoverContent className="w-48 p-0" align="start">
          <Command>
            <CommandInput placeholder="搜索仓库..." className="h-8 text-[13px]" />
            <CommandList>
              <CommandEmpty className="py-2 text-center text-[13px]">未找到仓库</CommandEmpty>
              <CommandGroup>
                <CommandItem
                  onSelect={() => {
                    setSelectedWarehouses([]);
                  }}
                  className="text-[13px]"
                >
                  <Check className={cn("mr-2 h-4 w-4", selectedWarehouses.length === 0 ? "opacity-100" : "opacity-0")} />
                  全部
                </CommandItem>
                {warehouses.map((wh) => (
                  <CommandItem
                    key={wh.value}
                    value={wh.value}
                    onSelect={(currentValue) => {
                      setSelectedWarehouses(prev => 
                        prev.includes(wh.value) 
                          ? prev.filter(v => v !== wh.value)
                          : [...prev, wh.value]
                      );
                    }}
                    className="text-[13px]"
                  >
                    <Check
                      className={cn(
                        "mr-2 h-4 w-4",
                        selectedWarehouses.includes(wh.value) ? "opacity-100" : "opacity-0"
                      )}
                    />
                    {wh.label}
                  </CommandItem>
                ))}
              </CommandGroup>
            </CommandList>
          </Command>
        </PopoverContent>
      </Popover>

      {/* 模糊查询+下拉单选 供应商 */}
      <Popover open={openSupplier} onOpenChange={setOpenSupplier}>
        <PopoverTrigger className="inline-flex items-center whitespace-nowrap rounded-md font-medium transition-colors focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring disabled:pointer-events-none disabled:opacity-50 border border-input bg-background hover:bg-accent hover:text-accent-foreground w-48 h-8 px-3 text-[13px] border-gray-300 justify-between">
          {supplier
            ? suppliers.find((s) => s.value === supplier)?.label
            : "选择供应商..."}
          <ChevronsUpDown className="ml-2 h-4 w-4 shrink-0 opacity-50" />
        </PopoverTrigger>
        <PopoverContent className="w-48 p-0" align="start">
          <Command>
            <CommandInput placeholder="搜索供应商..." className="h-8 text-[13px]" />
            <CommandList>
              <CommandEmpty className="py-2 text-center text-[13px]">未找到供应商</CommandEmpty>
              <CommandGroup>
                <CommandItem
                  onSelect={() => {
                    setSupplier('');
                    setOpenSupplier(false);
                  }}
                  className="text-[13px]"
                >
                  <Check className={cn("mr-2 h-4 w-4", supplier === '' ? "opacity-100" : "opacity-0")} />
                  全部
                </CommandItem>
                {suppliers.map((s) => (
                  <CommandItem
                    key={s.value}
                    value={s.value}
                    onSelect={(currentValue) => {
                      setSupplier(s.value);
                      setOpenSupplier(false);
                    }}
                    className="text-[13px]"
                  >
                    <Check
                      className={cn(
                        "mr-2 h-4 w-4",
                        supplier === s.value ? "opacity-100" : "opacity-0"
                      )}
                    />
                    {s.label}
                  </CommandItem>
                ))}
              </CommandGroup>
            </CommandList>
          </Command>
        </PopoverContent>
      </Popover>

      <FeatureMarker title="更多筛选" description="交互说明：点击执行更多筛选操作。">
      <Button variant="outline" className="h-8 px-3 text-[13px] border-gray-300 text-gray-700">
        <Filter className="w-4 h-4 mr-1" />
        更多筛选
      </Button>
      </FeatureMarker>

      <FeatureMarker title="重置" description="交互说明：点击执行重置操作。">
      <Button variant="ghost" className="h-8 px-3 text-[13px] text-gray-500 hover:text-gray-700" onClick={() => {
        setSupplier('');
        setSelectedWarehouses([]);
      }}>
        重置
      </Button>
      </FeatureMarker>
    </div>
  );
}
